<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class media extends Model
{
    //
     // Tentukan nama tabel yang terkait dengan model ini
    //  protected $table = 'data_siswa';
}