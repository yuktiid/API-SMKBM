<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kategori extends Model
{
    // Tentukan nama tabel yang terkait dengan model ini
    protected $table = 'kategoris';

    // Tentukan nama kolom yang boleh diisi dalam tabel
    
}