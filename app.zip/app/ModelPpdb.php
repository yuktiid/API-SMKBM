<?php
namespace App;
use Illuminate\Database\Eloquent\Model;


class ModelPpdb extends Model{
    protected $table = 'data_siswa';


}
// class ModelOrtu extends Model{
//     protected $table = 'data_ortu';

// }


?>