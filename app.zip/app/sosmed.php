<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sosmed extends Model
{
    // Tentukan nama tabel yang terkait dengan model ini
    protected $table = 'sosmeds';

    // Tentukan nama kolom yang boleh diisi dalam tabel
    // protected $fillable = ['id', '', 'kolom3'];
}